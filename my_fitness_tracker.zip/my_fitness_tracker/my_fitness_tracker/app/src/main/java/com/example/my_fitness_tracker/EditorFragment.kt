package com.example.my_fitness_tracker

import android.app.Activity
import android.os.Build
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.Switch
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.my_fitness_tracker.EditorFragmentArgs
import com.example.my_fitness_tracker.EditorViewModel

import com.example.my_fitness_tracker.data.NoteEntity
import com.example.plainolnotes4.R
import com.example.plainolnotes4.databinding.EditorFragmentBinding


import kotlinx.android.synthetic.main.editor_fragment.*
import kotlinx.android.synthetic.main.list_item.*
import java.sql.Date
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class EditorFragment : Fragment() {

    private lateinit var viewModel: EditorViewModel
    private val args: EditorFragmentArgs by navArgs()
    private lateinit var binding: EditorFragmentBinding

    //when using view to create new workout
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        (activity as AppCompatActivity).supportActionBar?.let {
            it.setHomeButtonEnabled(true)
            it.setDisplayShowHomeEnabled(true)
            it.setDisplayHomeAsUpEnabled(true)
            it.setHomeAsUpIndicator(R.drawable.ic_check)
        }
        setHasOptionsMenu(true)

        requireActivity().title =
            if (args.noteId == NEW_NOTE_ID) {
                getString(R.string.new_note)
            } else {
                getString(R.string.edit_note)
            }

        viewModel = ViewModelProvider(this).get(EditorViewModel::class.java)
// set all as empty
        binding = EditorFragmentBinding.inflate(inflater, container, false)
        binding.editor.setText("")
        binding.place.setText("")
        binding.editTextDate.setText("")
        binding.editStartTime.setText("")
        binding.editEndTime.setText("")
        binding.inGroupSwitch.setText("")



        requireActivity().onBackPressedDispatcher.addCallback(
            viewLifecycleOwner,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    saveAndReturn()
                }
            }

        )


//save vals for new db entry
        viewModel.currentNote.observe(viewLifecycleOwner, Observer {
            val savedString = savedInstanceState?.getString(NOTE_TEXT_KEY)
            val cursorPosition = savedInstanceState?.getInt(CURSOR_POSITION_KEY) ?: 0
            binding.editor.setText(savedString ?: it.title)
            binding.editor.setSelection(cursorPosition)
            binding.place.setText(savedInstanceState?.getString(NOTE_PLACE_KEY) ?: it.place)
            binding.editTextDate.setText(savedInstanceState?.getString(NOTE_ENTEREDDATE_KEY) ?: it.enteredDate)
            binding.editStartTime.setText(savedInstanceState?.getString(NOTE_STARTIME_KEY) ?: it.startTime)
            binding.editEndTime.setText(savedInstanceState?.getString(NOTE_ENDTIME_KEY) ?: it.endTime)

            if (savedInstanceState?.getString(NOTE_INDIVORGROUP_KEY) == "true") {
                binding.inGroupSwitch.setChecked(true)
            } else if (savedInstanceState?.getString(NOTE_INDIVORGROUP_KEY) == "false"){
                binding.inGroupSwitch.setChecked(false)
            } else {
                if (viewModel.currentNote.value?.indivOrGroup == true) {
                    binding.inGroupSwitch.setChecked(true)
                } else {
                    binding.inGroupSwitch.setChecked(false)
                }
            }





        })
        viewModel.getNoteById(args.noteId)


        binding.todayButton.setOnClickListener{
            val current = LocalDateTime.now()
            val formatter = DateTimeFormatter.ofPattern("dd/MM/yy")
            val formatted = current.format(formatter)


            binding.editTextDate.setText(formatted)

        }


        return binding.root


    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> saveAndReturn()
            else -> super.onOptionsItemSelected(item)
        }
    }
//when edit is saved update in main frag
    private fun saveAndReturn(): Boolean {

        val imm = requireActivity()
            .getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(binding.root.windowToken, 0)
        viewModel.currentNote.value?.title = binding.editor.text.toString()
        viewModel.currentNote.value?.place = binding.place.text.toString()
        viewModel.currentNote.value?.enteredDate = binding.editTextDate.text.toString()
        viewModel.currentNote.value?.startTime = binding.editStartTime.text.toString()
        viewModel.currentNote.value?.endTime = binding.editEndTime.text.toString()
        val toggle: Switch = binding.inGroupSwitch
            if (toggle.isChecked) {
                viewModel.currentNote.value?.indivOrGroup = true

            } else {
                viewModel.currentNote.value?.indivOrGroup = false
        }




        viewModel.updateNote()

        findNavController().navigateUp()

        Toast.makeText(activity,"Note Updated!",Toast.LENGTH_SHORT).show();



        return true

    }

    override fun onSaveInstanceState(outState: Bundle) {
        with(binding) {
            outState.putString(NOTE_TEXT_KEY, editor.text.toString())
            outState.putInt(CURSOR_POSITION_KEY, editor.selectionStart)
            outState.putString(NOTE_PLACE_KEY, place.text.toString())
            outState.putString(NOTE_STARTIME_KEY, editStartTime.text.toString())
            outState.putString(NOTE_ENDTIME_KEY, editEndTime.text.toString())
            outState.putString(NOTE_ENTEREDDATE_KEY, editTextDate.text.toString())
            val toggle: Switch = binding.inGroupSwitch
            if (toggle.isChecked) {
                outState.putString(NOTE_INDIVORGROUP_KEY, "true")

            } else {
                outState.putString(NOTE_INDIVORGROUP_KEY, "false")
            }

        }
        super.onSaveInstanceState(outState)
    }

}