package com.example.my_fitness_tracker

const val NEW_NOTE_ID = 0
const val TAG = "noteLogging"
const val NOTE_TEXT_KEY = "noteTextKey"
const val NOTE_PLACE_KEY = "notePlaceKey"
const val NOTE_STARTIME_KEY = "noteStartTimeKey"
const val NOTE_ENDTIME_KEY = "noteEndTimeKey"
const val NOTE_INDIVORGROUP_KEY = "true"
const val NOTE_ENTEREDDATE_KEY = "noteEnteredDateKey"
const val CURSOR_POSITION_KEY = "cursorPositionKey"
const val SELECTED_NOTES_KEY = "selectedNotesKey"