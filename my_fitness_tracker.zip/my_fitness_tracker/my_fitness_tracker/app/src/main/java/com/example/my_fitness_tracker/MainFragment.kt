package com.example.my_fitness_tracker

import android.content.DialogInterface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
//import com.example.my_fitness_tracker.NEW_NOTE_ID
import com.example.my_fitness_tracker.SELECTED_NOTES_KEY
import com.example.my_fitness_tracker.TAG


import com.example.my_fitness_tracker.data.NoteEntity
import com.example.plainolnotes4.R
import com.example.plainolnotes4.databinding.MainFragmentBinding

class MainFragment : Fragment(),
    NotesListAdapter.ListItemListener {

    private lateinit var viewModel: MainViewModel
    private lateinit var binding: MainFragmentBinding
    private lateinit var adapter: NotesListAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        (activity as AppCompatActivity)
            .supportActionBar?.setDisplayHomeAsUpEnabled(false)
        setHasOptionsMenu(true)
        requireActivity().title = getString(R.string.app_name)
        binding = MainFragmentBinding.inflate(inflater, container, false)
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)

        with(binding.recyclerView) {
            setHasFixedSize(true)
            val divider = DividerItemDecoration(
                context, LinearLayoutManager(context).orientation)
            addItemDecoration(divider)
        }

        viewModel.notesList?.observe(viewLifecycleOwner, Observer {
            Log.i("noteLogging", it.toString())
            adapter = NotesListAdapter(it, this@MainFragment)
            binding.recyclerView.adapter = adapter
            binding.recyclerView.layoutManager = LinearLayoutManager(activity)
            val selectedNotes =
                savedInstanceState?.getParcelableArrayList<NoteEntity>(SELECTED_NOTES_KEY)
            adapter.selectedNotes.addAll(selectedNotes ?: emptyList())
        })
        binding.floatingActionButton.setOnClickListener {
           editNote(NEW_NOTE_ID)
        }
        return binding.root
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        val menuId =
            if (this::adapter.isInitialized &&
                adapter.selectedNotes.isNotEmpty()
            ) {
                R.menu.menu_main_selected_items
            } else {
                R.menu.menu_main
            }
        inflater.inflate(menuId, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_sample_data -> addSampleData()
            R.id.action_delete -> deleteSelectedNotes()
            R.id.action_delete_all -> deleteAllNotes()
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun deleteAllNotes(): Boolean {

        var builder = AlertDialog.Builder(requireActivity())
        builder.setTitle(getString(R.string.delete_title))
        builder.setMessage("Are you sure you would like to delete all notes?")
        builder.setPositiveButton("Yes", DialogInterface.OnClickListener{dialog, id ->
            viewModel.deleteAllNotes()
            dialog.cancel()
            Toast.makeText(activity,"All Notes Deleted!",Toast.LENGTH_SHORT).show();
        })
        builder.setNegativeButton("No", DialogInterface.OnClickListener{ dialog, id ->
            dialog.cancel()
            Toast.makeText(activity,"Delete Canceled!",Toast.LENGTH_SHORT).show();
        })
        var alert = builder.create()
        alert.show()

        return true

    }

    private fun deleteSelectedNotes(): Boolean {

    var builder = AlertDialog.Builder(requireActivity())
    builder.setTitle(getString(R.string.delete_title))
    builder.setMessage(getString(R.string.delete_selected_msg))
    builder.setPositiveButton("Yes", DialogInterface.OnClickListener{dialog, id ->
        viewModel.deleteNotes(adapter.selectedNotes)
        Handler(Looper.getMainLooper()).postDelayed({
            adapter.selectedNotes.clear()
            requireActivity().invalidateOptionsMenu()
        }, 100)
        dialog.cancel()
        Toast.makeText(activity,"Notes Deleted!",Toast.LENGTH_SHORT).show();
    })
    builder.setNegativeButton("No", DialogInterface.OnClickListener{ dialog, id ->
        dialog.cancel()
        Toast.makeText(activity,"Delete Canceled!",Toast.LENGTH_SHORT).show();
    })
    var alert = builder.create()
        alert.show()


        return true
    }

    private fun addSampleData(): Boolean {
        viewModel.addSampleData()
        return true
    }

    override fun editNote(noteId: Int) {
        Log.i(TAG, "onItemClick: received note id $noteId")
        val action = MainFragmentDirections.actionEditNote(noteId)
        findNavController().navigate(action)
    }

    override fun onItemSelectionChanged() {
        requireActivity().invalidateOptionsMenu()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (this::adapter.isInitialized) {
            outState.putParcelableArrayList(
                SELECTED_NOTES_KEY,
                adapter.selectedNotes
            )
        }
        super.onSaveInstanceState(outState)
    }

}