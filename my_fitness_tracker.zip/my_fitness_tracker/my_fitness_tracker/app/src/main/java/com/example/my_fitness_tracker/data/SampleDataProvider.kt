package com.example.my_fitness_tracker.data

import java.util.*

class SampleDataProvider {

    companion object {
        private val sampleText1 = "Bike Ride"
        private val sampleText2 = "Gym Sesh"
        private val sampleText3 = "Swim"

        private fun getDate(diff: Long): Date {
            return Date(Date().time + diff)
        }

        fun getNotes() = arrayListOf(
            NoteEntity(getDate(0), sampleText1, "boardwalk", "10:00", "11:00", true, "27/10/21"),
            NoteEntity(getDate(1), sampleText2, "Gym", "16:00", "17:00", false, "25/10/21"),
            NoteEntity(getDate(2), sampleText3, "Beach", "5:00", "6:00", true, "26/10/21")
        )

    }
}